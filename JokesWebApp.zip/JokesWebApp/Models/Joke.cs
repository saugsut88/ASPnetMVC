﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace JokesWebApp.Models
{
    public class Joke
    {


        //class properties with getters and setters (type "prop" followed with tab 2x to auto generate)
        public int ID { get; set; }
        public string JokeQuestion { get; set; }
        public string JokeAnswer { get; set; }

        //constructor shortcut: ctor tab 2x to auto generate
        //constructor, left empty
        public Joke()
        {

        }

    }
}
